package com.example.velasquezmobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

import java.text.DecimalFormat;


    public class Activity1 extends AppCompatActivity implements View.OnClickListener {
        Button btnCTwoDay, btnCOvernight;
        EditText txtSender, txtReceiver,txtSAddress,txtRAddress;
        EditText txtWeight, txtCost,txtTotal;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_1);

            txtSAddress = (EditText) findViewById(R.id.txtSAddress);
            txtRAddress = (EditText) findViewById(R.id.txtRAddress);
            txtTotal = (EditText) findViewById(R.id.txtTotal);
            txtSender = (EditText) findViewById(R.id.txtSender);
            txtReceiver = (EditText) findViewById(R.id.txtReceiver);
            txtWeight = (EditText) findViewById(R.id.txtWeight);
            txtCost = (EditText) findViewById(R.id.txtCost);
            btnCOvernight = (Button) findViewById(R.id.btnCOvernight);
            btnCTwoDay = (Button) findViewById(R.id.btnCTwoDay);

            btnCOvernight.setOnClickListener(this);
            btnCTwoDay.setOnClickListener(this);
        }

        @Override
        public void onClick (View v){
            DecimalFormat df = new DecimalFormat("#.##");
            String SAddress = String.valueOf(txtSender.getText());
            String RAddress = String.valueOf(txtReceiver.getText());
            double weight = Double.parseDouble(String.valueOf(txtWeight.getText()));
            double cost = Integer.parseInt(String.valueOf(txtCost.getText()));

            switch(v.getId()){
                case R.id.btnCTwoDay:
                    txtSAddress.setText(String.valueOf(SAddress));
                    txtRAddress.setText(String.valueOf(RAddress));

                    TwoDays td = new TwoDays(SAddress,RAddress,weight,cost);
                    double tCost = td.calculateCost();
                    txtTotal.setText(String.valueOf(df.format(tCost)));
                    Toast.makeText(Activity1.this, "Two Day Shipping succesfully computed", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.btnCOvernight:
                    txtSAddress.setText(String.valueOf( SAddress));
                    txtRAddress.setText(String.valueOf( RAddress));

                    Overnight ovn = new Overnight(SAddress,RAddress,weight,cost);
                    tCost = ovn.calculateCost();
                    txtTotal.setText(String.valueOf(df.format(tCost)));
                    Toast.makeText(Activity1.this, "Overnight  Shipping succesfully is computed", Toast.LENGTH_SHORT).show();
                    break;

                default:
                    throw new IllegalStateException("Unexpected Value: "+v.getId());
            }
        }
    }