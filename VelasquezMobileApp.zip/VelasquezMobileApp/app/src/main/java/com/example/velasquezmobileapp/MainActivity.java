package com.example.velasquezmobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnHelloWorld, btnExercise1, btnActivity1, btnActivity2, btnActivity3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHelloWorld = (Button) findViewById(R.id.btnHelloWorld);
        btnExercise1 = (Button) findViewById(R.id.btnExercise1);
        btnActivity1 = (Button) findViewById(R.id.btnActivity1);
        btnActivity2 = (Button) findViewById(R.id.btnActivity2);
        btnActivity3 = (Button) findViewById(R.id.btnActivity3);

        /*btnHelloWorld.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(MainActivity.this, "This button is clicked!", Toast.LENGTH_SHORT).show();

            }
        });
*/

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnHelloWorld:
                Toast.makeText(this, "This button is clicked!", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, HelloWorld.class);
                startActivity(intent1);
                break;
            case R.id.btnExercise1:
                Toast.makeText(this, "This button is clicked!", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(this, MyActivity1Circle.class);
                startActivity(intent2);
                break;
            case R.id.btnActivity1:
                Toast.makeText(this, "This button is clicked!", Toast.LENGTH_SHORT).show();
                Intent intent3 = new Intent(this, Activity1.class);
                startActivity(intent3);
                break;
            case R.id.btnActivity2:
                Toast.makeText(this, "This button is clicked!", Toast.LENGTH_SHORT).show();
                Intent intent4 = new Intent(this, MainActivity2_Menu.class);
                startActivity(intent4);
                break;
            case R.id.btnActivity3:
                Toast.makeText(this, "This button is clicked!", Toast.LENGTH_SHORT).show();
                break;

        }

    }
}