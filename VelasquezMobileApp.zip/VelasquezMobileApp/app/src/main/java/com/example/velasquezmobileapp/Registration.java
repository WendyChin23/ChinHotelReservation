package com.example.velasquezmobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registration extends AppCompatActivity {
    Button btnsubmitreg, btnclearreg;
    EditText txtFirstname, txtLastname, txtphonenumber, txtemailadd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

                EditText editTextFirstName= (EditText) findViewById(R.id.txtFirstname);
                EditText editTextLastName = (EditText) findViewById(R.id.txtLastname);
                EditText editTextContact= (EditText)findViewById(R.id.txtphonenumber);
                EditText editTextEmailAdd=(EditText)findViewById(R.id.txtemailadd);
                btnsubmitreg =(Button) findViewById(R.id.btnsubmitreg);
                btnclearreg =(Button) findViewById(R.id.btnclearreg);
                btnclearreg.setOnClickListener(new View.OnClickListener() {
                    Button clear =(Button) findViewById(R.id.btnclearreg);


                    @Override
                    public void onClick(View v) {
                        editTextFirstName.setText(" ");
                        editTextLastName.setText(" ");
                        editTextContact.setText(" ");
                        editTextEmailAdd.setText(" ");
                    }

                });

                btnsubmitreg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String fname= editTextFirstName.getText().toString();
                        String lname= editTextLastName.getText().toString();
                        String name= fname.concat(" ").concat(lname);
                        String conum=editTextContact.getText().toString();
                        String emailadd=editTextEmailAdd.getText().toString();
                        Intent intent =new Intent(getApplicationContext(), Activity_Display.class);

                        intent.putExtra( "name_key",name);
                        intent.putExtra("contact_key",conum);
                        intent.putExtra("emailadd_key",emailadd);

                        startActivity(intent);


                    }
                });

            }
        }

