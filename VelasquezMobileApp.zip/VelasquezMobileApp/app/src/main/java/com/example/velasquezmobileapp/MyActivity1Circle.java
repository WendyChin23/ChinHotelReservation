package com.example.velasquezmobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MyActivity1Circle extends AppCompatActivity {

    //declare all the components

    Button btnCalculate;
    EditText txtArea, txtCircumference;
    EditText txtRadius;
    Circle c = new Circle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_activity1_circle);

        btnCalculate = (Button) findViewById(R.id.btnCalculate);
        txtArea = (EditText) findViewById(R.id.txtArea);
        txtRadius = (EditText) findViewById(R.id.txtRadius);
        txtCircumference = (EditText) findViewById(R.id.txtCircumference);

        btnCalculate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                DecimalFormat df = new DecimalFormat("#.##");
                //retrieves the value
                double radius = Integer.parseInt(String.valueOf(txtRadius.getText()));

                //set raiud of the circle by calling the setter method
                c.setRadius(radius);

                
                // compute the value
                double area = c.getArea();
                double circumference = c.getCircumference();

                //displays the value
                txtArea.setText(String.valueOf(df.format(area)));
                txtCircumference.setText(String.valueOf(df.format(circumference)));

                Toast.makeText(MyActivity1Circle.this, "Area and Circumference of the Circle has been computed!", Toast.LENGTH_SHORT).show();


            }
        });

    }
}