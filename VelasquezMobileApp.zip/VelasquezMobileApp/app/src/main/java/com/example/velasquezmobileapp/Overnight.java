package com.example.velasquezmobileapp;


    public class Overnight extends Package{
        private double addFee = 180.50;


        public Overnight(String SAddress,String RAddress, double weight, double cost){
            super(SAddress, RAddress, weight,cost);
        }
        public Overnight(String SAddress,String RAddress, double weight, double cost, double addFee){
            super(SAddress, RAddress, weight,cost);
            this.addFee = addFee;
        }
        public void setAddFee(double addFee){
            this.addFee = addFee;
        }
        public double getAddFee(){
            return addFee;
        }
        @Override
        public double calculateCost(){
            double adFee = addFee + (getWeight() * getCost());
            return adFee;
        }
    }

