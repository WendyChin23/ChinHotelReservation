package com.example.velasquezmobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_Display extends AppCompatActivity  implements View.OnClickListener{
    Button btnokay;
    TextView textViewName, textViewPhonenumber, textViewEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__display);


                TextView textViewName = (TextView) findViewById(R.id.textViewName);
                TextView textViewPhonenumber = (TextView) findViewById(R.id.textViewPhonenumber);
                TextView textViewEmailAdd = (TextView) findViewById(R.id.textViewEmail);
                btnokay = (Button) findViewById(R.id.btnokay);

                Intent intent = getIntent();

                String name = ((Intent) intent).getStringExtra("name_key");
                String contact = intent.getStringExtra("contact_key");
                String emailadd = intent.getStringExtra("emailadd_key");
                String add = intent.getStringExtra("add_key");
                textViewName.setText(name);
                textViewPhonenumber.setText(contact);
                textViewEmailAdd.setText(emailadd);
                btnokay.setOnClickListener((View.OnClickListener) this);

            }


@Override
            public void onClick (View v){
                //switch (v.getId()) {
                switch (v.getId()) {
                    case R.id.btnokay:
                        Toast.makeText(this, "Ok button is clicked!", Toast.LENGTH_SHORT).show();
                        Intent intent1 = new Intent(this, MainActivity2_Menu.class);
                        startActivity(intent1);
                        break;

                }
            }
}