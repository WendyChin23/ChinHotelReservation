/*package com.example.velasquezmobileapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Toast;

public class Activity_MainActivity2_Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__main_activity2__menu);
    }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.activity2_menu,menu);
            //  inflater.inflate(R.activity_main_activity2_menu);

            return true;
            //return super.onCreateOptionsMenu(menu);
        }

        @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.menuItem1:
                    Toast.makeText(this, "Register Menu is clicked!", Toast.LENGTH_SHORT).show();
                    return true;

                case R.id.menuItem2:
                    Toast.makeText(this, "View List is clicked!", Toast.LENGTH_SHORT).show();
                    return true;
            }
            return true;

    }
}*/