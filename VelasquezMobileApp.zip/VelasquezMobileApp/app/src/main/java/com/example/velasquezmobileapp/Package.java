package com.example.velasquezmobileapp;

    public abstract class Package {
        private String senderAddress;
        private String receiverAddress;
        private double weight;
        private double cost;

        public Package(String senderAddress,String receiverAddress, double weight, double cost){
            this.senderAddress = senderAddress;
            this.receiverAddress = receiverAddress;
            this.weight = weight;
            this.cost = cost;
        }
        public void setSenderAdd(String senderAddress){
            this.senderAddress = senderAddress;
        }
        public void setReceiverAdd(String receiverAddress){
            this.receiverAddress = receiverAddress;
        }
        public void setWeight(double weight){
            if(weight>0) {
                this.weight = weight;
            }
        }
        public void setCost(double cost){
            if(cost>0) {
                this.cost = cost;
            }
        }
        public String getSenderAdd(){
            return senderAddress;
        }
        public String getReceiverAdd(){
            return receiverAddress;
        }
        public double getWeight(){
            return weight;
        }
        public double getCost(){

            return cost;
        }

        public abstract double calculateCost();
    }


