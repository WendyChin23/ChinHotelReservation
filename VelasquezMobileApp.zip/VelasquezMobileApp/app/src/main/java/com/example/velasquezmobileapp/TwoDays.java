package com.example.velasquezmobileapp;

public class TwoDays  extends Package{
    private double flatFee = 80.50;
    public TwoDays(String SAddress,String RAddress, double weight, double cost){
        super(SAddress, RAddress, weight,cost);
    }
    public TwoDays(String SAddress,String RAddress, double weight, double cost, double flatFee){
        super(SAddress, RAddress, weight,cost);
        this.flatFee = flatFee;
    }
    public void setFlatFee(double flatFee){
        this.flatFee = flatFee;
    }
    public double getFlatFee(){
        return flatFee;
    }

    @Override
    public double calculateCost(){
        double fee = flatFee + (getWeight() * getCost());
        return fee;
    }
}

